#include "sequence.h"

std::vector<size_t> DnaSequence::_dnaTable;
DnaSequence::TableFiller DnaSequence::_filler;
